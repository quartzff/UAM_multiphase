function output = UAV_Endpoint(input)

output.objective = input.phase.integral;

